#ifndef PLAYSCENE_HPP
#define PLAYSCENE_HPP
#include <allegro5/allegro_audio.h>
#include <list>
#include <memory>
#include <utility>
#include <vector>

#include "Engine/IScene.hpp"
#include "Engine/Point.hpp"
#include "Tool/Shovel.hpp"
#include "Props/CoinBox.h"
#include "Props/FreeTurret.h"

extern int Score;
extern int Freezerskinchoose;
extern int Laserskinchoose;
extern int MachineGunskinchoose;
extern int Missileskinchoose;
extern std::vector<int> LevelScore;

class Turret;
namespace Engine {
	class Group;
	class Image;
	class Label;
	class Sprite;
}  // namespace Engine

class PlayScene final : public Engine::IScene {
private:
	enum TileType {
		TILE_DIRT,
		TILE_FLOOR,
		TILE_OCCUPIED,
	};
	ALLEGRO_SAMPLE_ID bgmId;
	std::shared_ptr<ALLEGRO_SAMPLE_INSTANCE> deathBGMInstance;
protected:
	int lives;
	int money;
	int SpeedMult;
    int CoinBox_count;
    int FreeTurret_count;
public:
	static bool DebugMode;
	static const std::vector<Engine::Point> directions;
	static const int MapWidth, MapHeight;
	static const int BlockSize;
	static const float DangerTime;
	static const Engine::Point SpawnGridPoint;
	static const Engine::Point EndGridPoint;
	static const std::vector<int> code;
	int MapId;
	float ticks;
	float deathCountDown;
	// Map tiles.
	Group* TileMapGroup;
	Group* GroundEffectGroup;
	Group* DebugIndicatorGroup;
	Group* BulletGroup;
	Group* TowerGroup;
	Group* EnemyGroup;
	Group* EffectGroup;
	Group* UIGroup;
    Group* LVGroup;
	Engine::Label* UIMoney;
    Engine::Label* UIFreeTurret;
	Engine::Label* UILives;
    Engine::Label* UICoinBox;
    Engine::Label* LVFire;
    Engine::Label* LVLaser;
    Engine::Label* LVMissile;
    Engine::Label* LVFreezer;
	Engine::Image* imgTarget;
    Engine::Image* Fireimg;
    Engine::Image* Laserimg;
    Engine::Image* Missileimg;
    Engine::Image* Freezerimg;
	Engine::Sprite* dangerIndicator;
	Turret* preview;
    Shovel* shovel_preview;
    CoinBox* CoinBox_preview;
    FreeTurret* FreeTurret_preview;
	std::vector<std::vector<TileType>> mapState;
	std::vector<std::vector<int>> mapDistance;
	std::list<std::pair<int, float>> enemyWaveData;
	std::list<int> keyStrokes;
	static Engine::Point GetClientSize();
	explicit PlayScene() = default;
	void Initialize() override;
	void Terminate() override;
	void Update(float deltaTime) override;
	void Draw() const override;
	void OnMouseDown(int button, int mx, int my) override;
	void OnMouseMove(int mx, int my) override;
	void OnMouseUp(int button, int mx, int my) override;
	void OnKeyDown(int keyCode) override;
	void Hit();
	int GetMoney() const;
	void EarnMoney(int money);
	void ReadMap();
	void ReadEnemyWave();
	void ConstructUI();
	void UIBtnClicked(int id);
	bool CheckSpaceValid(int x, int y);
	std::vector<std::vector<int>> CalculateBFSDistance();
    void BackOnClick();
    void LevelOnClick(int id);
    void construct_level();
	// void ModifyReadMapTiles();
};
#endif // PLAYSCENE_HPP
